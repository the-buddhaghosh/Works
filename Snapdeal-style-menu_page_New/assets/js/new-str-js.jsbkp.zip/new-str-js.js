$(document).ready(function(){
	
$('#expolre-more-cat-1,#expolre-more-cat-2').hide();
var btnText = document.getElementById("expand_more1");
$('#expand_more1').click(function(e) {
    e.preventDefault();
    $('#expolre-more-cat-1').slideToggle(1000);
    if (btnText.innerHTML == "Expand More") 
    {
         btnText.innerHTML = "Collapse";
    }
    else
    {
        btnText.innerHTML = "Expand More";
    }
});
/*-----------------2nd----------------*/
var btnText = document.getElementById("expand_more2");
$('#expand_more2').click(function(e) {
	e.preventDefault();
    $('#expolre-more-cat-2').slideToggle(1000);
    if (btnText.innerHTML == "Expand More") 
    {
    	 btnText.innerHTML = "Collapse";
    }
    else
    {
    	btnText.innerHTML = "Expand More";
    }
});
});